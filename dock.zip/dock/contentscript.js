//alert('From Content Script:'+document.title);

var sidePanelWidth=200;
var sidePanelMaxHeightPercent=0.90;
var dockSize=3;
var elemMap=new Map();
var dockedElemMap=new Map();
var DOCKANDGO_ON=false;

function centerStickyDiv() {
  const stickyDiv = document.querySelector('div#dockandgosidePanel');
  
  if (stickyDiv) {
      const viewportHeight = window.innerHeight;
      const divHeight = viewportHeight * sidePanelMaxHeightPercent; // 90% of viewport height
      stickyDiv.style.height = divHeight + 'px';
      stickyDiv.style.top = (viewportHeight - divHeight) / 2 + 'px'; 
      const stickyTriangleDiv = document.querySelector('div.dockandgotriangle-right');
      stickyTriangleDiv.style.top=((divHeight / 2)-6) + 'px'; 
  }

  for(let i=0;i<elemMap.size;i++)
  {   const b = document.querySelector("div#dockandgobutton_"+i);      
      const node=elemMap.get(i);
      const boxRect=getDocumentRelativeRect(node);
      const left = boxRect.right - 40; // 10px from the right edge, and 30px is the width of the button
      const top = boxRect.top + 10; // 10px from the top edge
      b.style.left=left+'px';
      b.style.top=top+'px';
    }
    
}

function initiateDockPanel()
{

  const sp=document.createElement("div");
	sp.id="dockandgosidePanel";
	sp.classList="dockandgoglasspane";
	const splist=document.createElement("ul");
	const tr=document.createElement("div");
	tr.classList="dockandgotriangle-right";
	sp.appendChild(splist);
	sp.appendChild(tr);
	document.body.appendChild(sp);
  
  centerStickyDiv(); // Initial centering

  window.addEventListener('resize', centerStickyDiv); // Recenter on resize
  sp.addEventListener('mouseenter',(e)=>
    {    
      sp.style.width = `${sidePanelWidth}px`;
      splist.style.transform='scale(1)'; 
      tr.style.opacity=0; 
  
    });

  sp.addEventListener('mouseleave',(e)=>
    {    
       sp.style.width = `1px`;  
       centerStickyDiv();
       splist.style.transform='scale(0)'; 
       tr.style.opacity=1; 
       sp.classList.remove('activedockandgoglasspane');
  
    });   

}

function isDarkMode() {
  const bodyStyle = window.getComputedStyle(document.body);
  const bgColor = bodyStyle.backgroundColor;

  // Handle transparent backgrounds
  if (bgColor === 'transparent' || bgColor === 'rgba(0, 0, 0, 0)') {
    //Check the background image instead.
    const backgroundImage = bodyStyle.backgroundImage;
    if(backgroundImage && backgroundImage !== 'none'){
      return false; //assume light mode if background image is used.
    }
    return false; // Treat transparent as light mode
  }

  // Extract RGB values
  const rgb = bgColor.match(/\d+/g);
  if (rgb) {
    const r = parseInt(rgb[0]);
    const g = parseInt(rgb[1]);
    const b = parseInt(rgb[2]);

    // Calculate luminance (more accurate than simple brightness)
    const luminance = 0.2126 * r + 0.7152 * g + 0.0722 * b;

    // Adjust threshold as needed (128 is a common starting point)
    return luminance < 128;
  }

  return false; // Default to light mode if color parsing fails
}

/* if (isDarkMode()) {
  alert('Theme Detection: Dark mode likely');
} else {
  alert('Theme Detection: Light mode likely');
}  */

function fixMissingShaDOMs(originalElement,clonedElement)
{
  if (!clonedElement) {
    return;
  }
 
  const stack2 = [clonedElement];
  const stack1 = [originalElement];

  while (stack1.length > 0) {
    const currentNode2 = stack2.pop();
    const currentNode1 = stack1.pop();
    if(typeof currentNode2=="undefined")continue;

    if(currentNode2.tagName=="YT-FORMATTED-STRING"&&currentNode1.tagName=="YT-FORMATTED-STRING")
    {
      //alert(currentNode1.innerText+"->"+currentNode2.innerText);    
      const spanElem=document.createElement('span');
      const newText = document.createTextNode(currentNode1.innerText);
      spanElem.appendChild(newText);
      currentNode2.insertAdjacentElement("beforebegin", spanElem);
      currentNode2.remove();
    }

    // Iterate through child nodes in reverse order to maintain correct order when using stack

    for (let i = currentNode2.childNodes.length - 1; i >= 0; i--) {
      stack2.push(currentNode2.childNodes[i]);
    }
    for (let i = currentNode1.childNodes.length - 1; i >= 0; i--) {
      stack1.push(currentNode1.childNodes[i]);
    }
  }

}

function createMirrorElement(originalElement, targetContainer) {
    // 1. Create a Shadow Host:
    const shadowHost = targetContainer;  
  
    // 2. Create the Shadow Root:
    const shadowRoot = shadowHost.attachShadow({ mode: 'open' }); // 'open' allows access via JS
  
    // 3. Clone the Original Element (Deep Clone):
    const clonedElement = originalElement.cloneNode(true);   
    clonedElement.style.transform=`none`;//basic fix for pinterest and websites with transforming html elements 

    // 4. Import Styles (Crucial for Preserving Styles):
    const styles = originalElement.ownerDocument.querySelectorAll('style, link[rel="stylesheet"]'); // Select all styles
    styles.forEach(style => {
      const importedStyle = document.importNode(style, true); // Import the style
      shadowRoot.appendChild(importedStyle); // Add styles to Shadow DOM
    });
   
      // 5. Clone the Element's computed styles and inject them into the shadow dom.
      const computedStyles = window.getComputedStyle(originalElement);
      const styleElement = document.createElement('style');
      let cssText = "";
      for (let i = 0; i < computedStyles.length; i++) {
          const propertyName = computedStyles[i];
          cssText += `${propertyName}: ${computedStyles.getPropertyValue(propertyName)};\n`;
      }
      styleElement.textContent = cssText;
      shadowRoot.appendChild(styleElement);
  
    fixMissingShaDOMs(originalElement,clonedElement);
  
    // 6. Append the Cloned Element to the Shadow Root:
    shadowRoot.appendChild(clonedElement);
    //shadowRoot.appendChild(clonedElementNode);
    //alert("clonedElement appended to shadowRoot");     
  
    return shadowHost;
  }
  
    

  function showDockableContent()
  {
    //alert("highlight content")
    //dockPopup()
    let path="";
    if(window.location.host.indexOf("youtube.com")>-1)
    { path='/html/body/ytd-app/div[1]/ytd-page-manager/ytd-browse/ytd-two-column-browse-results-renderer/div[1]/ytd-rich-grid-renderer/div[6]'
    }
    else if(window.location.host.indexOf("pinterest.com")>-1)
    {
    path="/html/body/div[1]/div[1]/div[2]/div/div/div/div[4]/div/div/div/div/div/div/div[2]/div/div/div/div/div/div[1]";
    }
    else if(window.location.host.indexOf("imdb.com")>-1)
    {
      path="/html/body/div[2]/main/div/div[3]/section/div/div[2]/div/div[5]";  
    }
    else if(window.location.host.indexOf("google.com")>-1)
    {
      path="/html/body/div[3]/div/div[14]/div/div[2]/div[2]/div/div/div/div/div[1]/div/div";
    }
    else if(window.location.host.indexOf("twitch.tv")>-1)
    { //action games only
      path="/html/body/div[1]/div/div[1]/div/main/div[1]/div[3]/div/div/div/div/div/section/div[2]/div";

    }
    else if(window.location.host.indexOf("instagram.com")>-1)
    { //first row only
      path="/html/body/div[1]/div/div/div[2]/div/div/div[1]/div[2]/div/div[1]/section/main/div/div[3]/article/div/div/div[1]";
    }
    else if(window.location.host.indexOf("ameba.jp")>-1)
    {
      path="/html/body/div/main/section/div[1]/ul";//https://choice.ameba.jp/categories/household-goods/
    }
    else if(window.location.host.indexOf("tiktok.com")>-1)
    {
      path="/html/body/div[1]/div[2]/div[2]/div/div[2]/div";
    }
    else if(window.location.host.indexOf("airbnb.co.nz")>-1)
     {
        path="/html/body/div[5]/div/div/div[1]/div/div[2]/div[2]/main/div[2]/div[1]/div/div/div/div";
    }
    else{alert('No content detected in this page'); return;}
  
  
  
  const originalElement = document.evaluate(path,document, null, XPathResult.FIRST_ORDERED_NODE_TYPE, null  ).singleNodeValue; 
  

  const buttonTemplateContent=`
 <div class="dockandgo-button" title="Dock this" role=“button” aria-pressed="false">

 <svg class="centered-svg" version="1.0" xmlns="http://www.w3.org/2000/svg"  width="600.000000pt" height="600.000000pt" viewBox="0 0 600.000000 600.000000"  preserveAspectRatio="xMidYMid meet">  <g transform="translate(0.000000,600.000000) scale(0.100000,-0.100000)" fill="#ff5500" stroke="none"> <path d="M587 5984 c-258 -46 -460 -221 -545 -469 -39 -115 -42 -187 -42 -1013 0 -937 1 -951 92 -1112 46 -81 92 -134 168 -190 261 -194 553 -181 850 38 41 30 110 89 153 131 l77 75 -243 245 c-212 214 -246 252 -261 295 -21 65 -20 104 4 170 24 62 87 127 141 144 38 12 459 126 949 257 531 142 909 244 1010 273 170 48 273 33 348 -53 66 -75 76 -142 41 -273 -11 -42 -32 -120 -45 -172 -14 -52 -34 -128 -46 -170 -11 -41 -26 -97 -33 -125 -20 -79 -86 -326 -122 -455 -8 -30 -19 -71 -23 -90 -4 -19 -17 -71 -30 -115 -34 -125 -51 -186 -65 -240 -16 -62 -59 -225 -87 -325 -11 -41 -22 -84 -25 -95 -6 -25 -29 -108 -50 -182 -26 -90 -60 -133 -136 -174 -48 -25 -147 -27 -203 -4 -27 11 -115 92 -281 258 l-243 241 -41 -39 c-64 -63 -182 -213 -233 -297 -25 -43 -58 -113 -73 -155 -25 -69 -28 -92 -28 -203 0 -105 4 -135 23 -190 71 -198 217 -347 412 -419 30 -11 102 -25 160 -30 148 -13 1699 -7 1768 7 236 50 435 220 523 447 44 114 43 59 46 1725 4 1426 2 1584 -13 1675 -9 55 -23 118 -31 140 -94 252 -293 422 -548 469 -81 14 -242 16 -1665 15 -1311 -1 -1588 -3 -1653 -15z"/> </g> </svg> 
</div>
  `;
  const buttonTemplate=document.createElement("template")
  buttonTemplate.innerHTML=buttonTemplateContent;
  document.body.appendChild(buttonTemplate);

  const dockandgoStyle=document.createElement("style");
  dockandgoStyle.innerHTML=`
  
div.dockandgooverlay{
  background: rgba(0, 0, 0, 0.1);
 
}

div.dockandgoglasspane { 
            position: fixed; /* Fixed position for viewport centering */
            right: 5px; /* Adjust right margin as needed */
            z-index: 9999;   			  		
			      margin:0px 0px 0px 0px;
            padding: 5px 5px 5px 5px;
            background: rgba(0, 0, 0, 0.4);
            border: thin solid rgba(0, 0, 0, 0.6);
            color: #eeeeee;
            font-family: Droid Sans, Arial, Helvetica, sans-serif;
            font-size: 12px;
            cursor: pointer;
            -webkit-box-shadow: rgba(0,0,0,0.5) 5px 5px 20px;
            -moz-box-shadow: rgba(0,0,0,0.5) 5px 5px 20px;
            box-shadow: rgba(0,0,0,0.5) 5px 5px 20px;  
			      white-space: nowrap; /* Prevent wrapping */
            width: 1px; /* Important to calculate width dynamically */
            transition: width 0.5s; /* Transition for width changes */
			      overflow: hidden;
  }

 div.dockandgoglasspane:hover
 { width:200px;
 }
 
 div.dockandgoglasspane:hover div.dockandgotriangle-right
 { opacity:0;
 }
 
 div.activedockandgoglasspane {
  transform: translateX(0); /* Fully visible */
}

 div.dockandgoglasspane ul
 { list-style-type: none ;   
   margin:0px;
   width: auto; /* Important to calculate width dynamically */
   white-space: nowrap; /* Prevent wrapping */
   transform-origin: center; /* Ensure scaling from the top */
   transform: scale(1);
   transition: transform 0.5s ease-in-out;
   padding:0px;  
      

  }        
 
  div.dockandgoglasspane li.dockeditem
  {
    display: flex; 
    justify-content: center; 
    align-items: center; 
    background: rgba(255, 255, 255, 0.8);   
    margin-bottom:5px;
    
    padding:0px;
    position:relative;/*adjusted for remove button*/
    overflow: hidden; /* To contain absolutely positioned child */
    transition: opacity 0.5s ease;

  }

  
    div.dockandgoglasspane li.dockeditem div
    {     
    
    justify-content: center; 
    align-items: center; 

    }

div.dockandgoglasspane div.dockandgotriangle-right {
  border: solid black;
  border-width: 0 3px 3px 0;
  display: block;
  padding: 3px;
  left:0px;
  transform: rotate(-45deg);
  -webkit-transform: rotate(-45deg);
    position:absolute;    
    transition: opacity 0.3s;
    opacity:1;
    
}

div.dockandgo-button {
      position: absolute;
      top: 10px;
      right: 10px;
      
      border-radius: 50%;
      width: 30px;
      height: 30px;
      display: flex;
      align-items: center;
      justify-content: center;
      vertical-align:middle;
      cursor: pointer;
      transition: all 0.3s ease;
      color: rgba(255,85,0,255);
      background-color: white;
      font-weight:bold;
    }

  div.dockandgo-button-toggle {
      background-color:  rgba(255,85,0,255);
      color: white;
    }

     div.dockandgo-button-toggle svg.centered-svg {
    filter:invert(100%) grayscale(100%) brightness(1000%)!important;
    }

    div.dockandgo-button:hover {
      background-color:  rgba(255,85,0,255);
      color: white;
    }
    div.dockandgo-button:active {
      background-color: white ;
      color: rgba(255,85,0,255);
    }
    
    div.dockandgo-button svg.centered-svg {
    position:absolute!important;
    width:80%!important;
    height:80%!important;
    top: 20%!important;
    left: 20%!important;

  }
    

div.dockandgo-button svg.centered-svg{
    transition: filter 0.3s ease!important; /* Smooth transition */
  }

  div.dockandgo-button:hover svg.centered-svg {
    filter:invert(100%) grayscale(100%) brightness(1000%)!important;
  }

 div.dockandgo-button:active svg.centered-svg{
    filter:none!important;

    }
  div.dockandgo-button svg.centered-svg *{
  transform-box: view-box!important;  
  }
  div.dockandgoglasspane li.dockeditem button.dockandgo-remove-button{
    position: absolute;
    top: 0;
    left: 0;
    height: auto; /* Extend to the full height of the li */
    width: 10%; /* Occupy 15% of the li's width */
    background-color: rgba(255, 0, 0, 0.8); /* Example red background */
    color: white;
    border: none;
    cursor: pointer;
    opacity: 0; /* Hidden by default */
    transition: opacity 0.3s ease; /* Smooth transition for visibility */
    z-index: 10; /* Ensure it's above other content */
    display: flex;
    justify-content: center;
    align-items: center;
    flex-direction: column; /* Arrange text vertically */
    font-size: 0.8em; /* Adjust font size as needed */
    writing-mode: vertical-lr; /* Make text vertical (left to right) */
    text-orientation: upright; /* Ensure letters are upright */
    overflow: hidden; /* Hide any overflowing text */


  }  
  
  div.dockandgoglasspane li.dockeditem:hover button.dockandgo-remove-button{
      opacity: 1; /* Show on hover */

  }  
  
  `;

  document.head.appendChild(dockandgoStyle);

  if(!originalElement||!originalElement.hasChildNodes()){alert('No content detected in this page'); return;}

  for(let i=0;i<originalElement.childNodes.length;i++)
  {
    const node=originalElement.childNodes[i];
    const boxRect =getDocumentRelativeRect(node);    
    let dockButton=buttonTemplate.content.cloneNode(true);  
    dockButton=dockButton.querySelector("div.dockandgo-button") ; 
    const left = boxRect.right -40; // 10px from the right edge, and 30px is the width of the button
    const top = boxRect.top + 10; // 10px from the top edge
    dockButton.style.left=left+'px';
    dockButton.style.top=top+'px';
    dockButton.style.zIndex=node.style.zIndex+1;
    dockButton.id="dockandgobutton_"+i;
    dockButton.addEventListener('click', () => {
      dockPopup(i);           
     });    
    document.body.appendChild(dockButton); 
    elemMap.set(i,node);
  }

  }

  function getDocumentRelativeRect(element) {
    const rect = element.getBoundingClientRect();
    const scrollLeft = window.pageXOffset || document.documentElement.scrollLeft;
    const scrollTop = window.pageYOffset || document.documentElement.scrollTop;
    return {
        left: rect.left + scrollLeft,
        top: rect.top + scrollTop,
        width: rect.width,
        height: rect.height,
        right: rect.right + scrollLeft,
        bottom: rect.bottom + scrollTop,
    };
}
  
 

  function dockPopup(nodeId)
  {
    if(!elemMap.has(nodeId)) return;
    if(dockedElemMap.has(nodeId)){ alert("Item already docked to side panel. Click 'Remove' from the right side panel to undock this!");return;}
    const sidePanel = document.getElementById('dockandgosidePanel');
    const ul_elem=sidePanel.firstElementChild; 

    if(dockedElemMap.size>=dockSize)
    { alert("More than three content docking will be available soon!");
      return;
    }
    
    const originalElement=elemMap.get(nodeId);
    
    const boundInfo=getDocumentRelativeRect(originalElement);
    const origWidth=boundInfo.width;
    const origHeight=boundInfo.height;
    const origLeft=boundInfo.left;
    const origTop=boundInfo.top;
     
    const elementToMove = document.createElement('div');  
    elementToMove.id='dockandgo_div_id_'+nodeId; // Where you want the mirror
    const mirror = createMirrorElement(originalElement, elementToMove);
    const arrow=sidePanel.querySelector("div.dockandgotriangle-right");   

  requestAnimationFrame(() => {
    sidePanel.style.width = `${sidePanelWidth}px`;
    ul_elem.style.transform='scale(1)'; 
    arrow.style.opacity=1;
  });
 
  requestAnimationFrame(() => {
    
    const new_li=document.createElement("li");
    new_li.classList.add("dockeditem");

     
    /* Auto adjust dimension code starts here */
    const availablePanelHeight = window.innerHeight * sidePanelMaxHeightPercent;
    const availableLiHeight = availablePanelHeight / dockSize; // Distribute height evenly (you might adjust this)   
    
    let fittingWidth = origWidth;
    let fittingHeight = origHeight;
    let scale = 1;
    
    let scaleByWidth = 1;
    if (origWidth > sidePanelWidth) {
      scaleByWidth = sidePanelWidth / origWidth;
    }
  
    // Calculate scale needed to fit within the available li height
    let scaleByHeight = 1;
    if (origHeight > availableLiHeight) {
      scaleByHeight = availableLiHeight / origHeight;
    }
    scale = Math.min(scaleByWidth, scaleByHeight, 1);

    new_li.style.height=`${availableLiHeight-10}px`;
    new_li.style.width=`${sidePanelWidth}px`;
    new_li.style.objectFit="contain";   
    ul_elem.appendChild(new_li);   

    //Docked item added here
     
    //elementToMove.style.position="absolute";
    //elementToMove.style.left=`${origLeft}px`;
    //elementToMove.style.top=`${origTop}px`;
    elementToMove.style.width=`${origWidth}px`;
    elementToMove.style.height=`${origHeight}px`;

    //elementToMove.style.transformOrigin=`0 0`;   
    elementToMove.style.transform=`scale(${scale})`;  
    //document.body.appendChild(elementToMove);
    //document.body.remove(elementToMove)
    new_li.appendChild(elementToMove);
    
    //Remove button added here
    const removeButton = document.createElement('button');
    removeButton.classList.add('dockandgo-remove-button');    
    removeButton.style.height=`${availableLiHeight-10}px`;
    removeButton.textContent = 'REMOVE';
    removeButton.setAttribute('data-item-id', nodeId); // Assign a unique ID
    new_li.appendChild(removeButton); // Insert before the inner-div
  
    removeButton.addEventListener('click', function() {
    const itemId = this.getAttribute('data-item-id');
    const parentListItem = this.parentNode;      
    parentListItem.style.opacity=0;

      requestAnimationFrame(() => {   
        parentListItem.remove();            
        dockedElemMap.delete(parseInt(itemId));   
        const b = document.querySelector("div#dockandgobutton_"+itemId);      
        b.classList.toggle("dockandgo-button-toggle");
        b.title="Dock this!";
      },500);

    });

    new_li.appendChild(removeButton);   
    arrow.style.opacity=0; 
    sidePanel.classList.add('activedockandgoglasspane');
   
    dockedElemMap.set(nodeId,originalElement);
    const b = document.querySelector("div#dockandgobutton_"+nodeId);      
    b.classList.toggle("dockandgo-button-toggle");
    b.title="Undock this!";
  }, 500); // Match animation duration
 
  setTimeout(() => {
    sidePanel.style.width = `1px`; 
    centerStickyDiv(); 
    ul_elem.style.transform='scale(0)'; 
    arrow.style.opacity=1; 
    sidePanel.classList.remove('activedockandgoglasspane');

  }, 2500); // Auto close panel
  
  
 }//end of dock button action

 
function showDNGExtension()
{
  initiateDockPanel();
  showDockableContent();
}
function hideDNGExtension()
{
  const stickyDiv = document.querySelector('div#dockandgosidePanel');
          if(stickyDiv)stickyDiv.remove();
                   

          const allDockButtons=document.querySelectorAll('div.dockandgo-button');
          if(allDockButtons)
          {
           for(let i=0;i<allDockButtons.length;i++)
            { const b=allDockButtons[i];
              b.remove();
            }
          }
          if(dockedElemMap.size>0)alert("Persistent docking is available for premium subscribed users only!");

          elemMap.clear();
          dockedElemMap.clear();
}
  chrome.runtime.onMessage.addListener(
    function(request, sender, sendResponse) {
      
      if (request.invoke === "showDock")
      {   
          DOCKANDGO_ON=true;
          showDNGExtension();
          
         /*  let cursorUrl = chrome.runtime.getURL('/images/cursor10.cur');
          document.body.style.cursor = `url(${cursorUrl}), auto`; */
          sendResponse({result: "success"});
      }
      else if (request.invoke === "hideDock")
      {   //document.body.style.cursor = 'default'; 
          DOCKANDGO_ON=false;
          hideDNGExtension();
          sendResponse({result: "success"});
        }

    }
  );

  function getBadgeText(callback) {
    chrome.runtime.sendMessage({ action: "getBadgeText" }, (response) => {
      
      if (response) {
        callback(response.badgeText);
       
      } else {
        
        callback(null); // Or handle the case where the badge text isn't available
      }
    });
  }


   
window.addEventListener('load', (event) => {
   
getBadgeText((badgeText) => {
  if (badgeText !== null) {
    if(badgeText=="ON")
    {//extension active
      DOCKANDGO_ON-true;
      showDNGExtension();
    }
    else
    { //extension inactive
      //alert(9);
      DOCKANDGO_ON=false;
      hideDNGExtension();
    }

    // Do something with the badge text
  } else {
    console.log("Could not retrieve badge text.");
  }
});

  });
  
  //use mutation observer of the dockable content xpath for SPA and other navigational issues