function orangenPage() {
  document.body.style.backgroundColor = 'orange';
  //alert(document.title);
 
}

chrome.action.onClicked.addListener((tab) => {
  if (!tab.url.includes('chrome://')) {
    //chrome.scripting.executeScript({ target: { tabId: tab.id }, function: orangenPage });
    (async () => {
      //chrome.action.setBadgeText({ text: '' }); // Clear the badge

      const [tab] = await chrome.tabs.query({active: true, lastFocusedWindow: true});

      chrome.action.getBadgeText({}, async function(result) {
        var badge = result;
        if(badge!="ON")
          {
            const response = await chrome.tabs.sendMessage(tab.id, {invoke: "showDock"});
            chrome.action.setBadgeText({ text: 'ON' });
    
          }
          else
          {
            const response = await chrome.tabs.sendMessage(tab.id, {invoke: "hideDock"});
            chrome.action.setBadgeText({ text: '' }); // Clear the badge
    
          }      
      });
      
     

    })();
  }
});

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === "getBadgeText") {
    chrome.action.getBadgeText({ tabId: sender.tab ? sender.tab.id : undefined }, (result) => {
      sendResponse({ badgeText: result });
    });
    return true; // Indicate that you want to send a response asynchronously
  }
});

